# weather-app
Run weatherapp.py file
